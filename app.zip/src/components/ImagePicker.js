import {
  StyleSheet,
  View,
  TextInput,
  Text,
  SafeAreaView,
  Image,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Alert,
} from "react-native";
import { useEffect, useState } from "react";
import { Ionicons } from "@expo/vector-icons";
import PrimaryButton from "./ui/PrimaryButton";
import {
  launchCameraAsync,
  useCameraPermissions,
  PermissionStatus,
} from "expo-image-picker";

export default function ImagePicker() {
    const [pickedImage,setPickedImage]=useState()
  const [cameraPermissionInformation, requestPermission] =
    useCameraPermissions();
  async function verifyPermissions() {
    if (cameraPermissionInformation.status === PermissionStatus.UNDETERMINED) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }
    if (cameraPermissionInformation.status === PermissionStatus.DENIED) {
      Alert.alert("Insufficient Permissons");
      return false;
    }
    return true;
  }
  async function takeImageHandler() {
    const hasPermissions = await verifyPermissions();
    if (!hasPermissions) {
      return;
    }
    const image = await launchCameraAsync({
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.5,
    });
    setPickedImage(image.assets[0].uri)
    console.log(image.assets[0].uri);
  }
  return (
    <View>
      <View style={styles.imagePreview}>
        <Image style={styles.image} source={{uri:pickedImage}}/>
      </View>
      <PrimaryButton pressButton={takeImageHandler}>Take Image</PrimaryButton>
    </View>
  );
}

const styles = StyleSheet.create({
    imagePreview:{
        height:150,
        width:'100%',
        marginVertical:8,
        justifyContent:'center',
        alignItems:'center',
    

    },
    image:{
        height:'100%',
        width:'100%',
    }
});
