import {
  StyleSheet,
  View,
  TextInput,
  Text,
  SafeAreaView,
  Image,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Alert,
} from "react-native";
import Colors from "../../constants/Colors.js";
import { useEffect, useState } from "react";
import { Ionicons } from "@expo/vector-icons";
export default function Temp() {
  return <View><Text>Temp</Text></View>;
}

const styles = StyleSheet.create({});
