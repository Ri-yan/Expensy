export const Colors={
    primaryNav:"#fff0f0",
    primaryNavIcon:"#cb90e9",
    primaryBackground:"#cb90e936",
    secondaryNav:"#7a67f8",
    textLight:'#fff'

}